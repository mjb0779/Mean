var mean = new Vue({
	el: '#mean',
	data: {
		start: 0,
		nextVal: 0,
		sum: 0,
		mean: 0,
		std: 0,
		count: 0,
		sqrSum: 0,
		array1: [],
		array2: [],
		array3: [],
		xArray: [],
		yArray: [],
		xValue: 0,
		yValue: 0,
		xNextVal: 0,
		yNextVal: 0,
		xSum: 0,
		ySum: 0,
		xAvg: 0,
		yAvg: 0,
		xySum: 0,
		xSqr: [],
		ySqr: [],
		xSqrSum: 0,
		ySqrSum: 0,
		corel: 0,
		regBet0: 0,
		regBet1: 0,
		regression: 0,
	
	},
	methods:{
		/* myArray1: function(){
			for(let i = this.start; i <= this.stop; i++){
				this.array1.push(i)
			}
		}, */
		
		myArray1: function(){
			this.start = this.nextVal
			this.array1.push(parseInt(this.start)) 
			/* this.array1 = b.split(",").map(Number) */
			
			console.log(this.array1)
		},
		myArray: function(){
			this.myArray1
			
		},
		myXarray: function(){
			this.xValue = this.xNextVal
			this.xArray.push(parseInt(this.xValue))
			console.log(this.xArray)
		},
		myYarray: function(){
			this.yValue = this.yNextVal
			this.yArray.push(parseInt(this.yValue))
			console.log(this.yArray)
		},
		display: function(){
			
			this.myArray()
			let calc = new Calculator(this.array1,this.xArray, this.yArray)
			
			this.sum = calc.calcSum(this.array1)
			this.mean = calc.calcMean(this.sum, this.array1)
			this.array2 = calc.myArray2(this.array1)
			this.array3 = calc.calcSqr(this.array2)
			this.sqrSum = calc.calcSum(this.array3)
			this.std =  calc.calcStd(this.sqrSum)
			
			
		},
		display2: function(){
			let calc = new Calculator(this.array1, this.xArray, this.yArray)
			this.xSum = calc.calcSum(this.xArray)
			this.xAvg = calc.calcMean(this.xSum, this.xArray)
			this.ySum = calc.calcSum(this.yArray)
			this.yAvg = calc.calcMean(this.ySum, this.yArray)
			this.xySum = calc.calcXYSum(this.xArray, this.yArray)
			this.xSqrSum = calc.calcSqr2(this.xArray, this.xSqr)
			this.ySqrSum = calc.calcSqr2(this.yArray, this.ySqr)
			
			this.regBet1 = (calc.calcXYSum(this.xArray,this.yArray) - (((this.xArray.length) * this.xAvg)*this.yAvg))/(calc.calcSum((calc.calcSqr(this.xArray))) - ((this.xArray.length) * (this.xAvg * this.xAvg)))
			
			console.log(calc.calcSum((calc.calcSqr(this.xArray))))
			
			this.regBet0 = this.yAvg - (this.regBet1 * this.xAvg)
			this.regression = this.regBet0 + this.regBet1 * this.xKey
			
			this.corel = ((this.n*this.xySum)-(this.xSum * this.ySum))/Math.sqrt(((this.xArray.length*this.xSqrSum) - (this.xSqrSum * this.xSqrSum)) * ((this.yArray.length*this.ySqrSum) - (this.ySqrSum*this.ySqrSum)))
			
			
		},
		
		reset: function(){
			this.sum = 0;
			this.mean = 0;
			this.count = 0;
			this.std = 0;
			this.array1 = [];
			this.array2 = [];
			this.array3 = [];
			this.xArray= [];
			this.yArray= [];
			this.xValue= 0;
			this.yValue= 0;
			this.xNextVal= 0;
			this.yNextVal= 0;
			this.dividend=0;
			this.xSum = 0;
			this.ySum = 0;
			this.xySum = 0;
			this.xSqr = [];
			this.ySqr = [];
			this.xSqrSum = 0;
			this.ySqrSum = 0;
			this.corel = 0;
			this.regA = 0;
			this.regB = 0;
			this.regression = 0;
		

		}
	}
})