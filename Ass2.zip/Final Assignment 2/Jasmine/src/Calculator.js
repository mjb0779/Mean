class Calculator{
	constructor (newArray1, newXArray, newYArray) {
		this.sum = 0
		this.mean = 0
		this.count = newArray1.length
		this.sqrSum = 0
		this.std = 0
		this.array1 = newArray1
		this.xArray = newXArray
		this.yArray = newYArray
		this.array2 = []
		this.array3 = []
		this.XYSum = 0
		this.xSqr = []
		this.ySqr = []
		this.xSqrSum = 0
		this.ySqrSum = 0
		this.n = 0
	}

	calcSum(allNumber){
		this.sum = allNumber.reduce((a,b) => a+=b)
		return this.sum
	}
	
	calcMean(){
		this.mean = this.sum/this.count
		return this.mean
	}
	myArray2(array){
		for(let a of array){
			this.array2.push(a-this.mean)
		}
		return this.array2
		console.log(array2)
	}
	calcSqr(array){
		for(let a of array){
			this.array3.push(a*a)
		}
		return this.array3
	}
	calcStd(sum){
		this.std = Math.sqrt(sum/(this.count-1))
		return this.std
	}
	calcXYSum(array1,array2){
		for(let a of array1){
			for(let b of array2){
				this.XYSum =a*b
			}
		}
		return this.XYSum
	}
	calcSqr2(array, inArray){
		for(let a of array){
			inArray.push(a*a)
		}
		return this.calcSum(inArray)
	}
	calcN(array1, array2){
		if(array1.length > array2.length){
			this.n = array2.length
		}else{
			this.n = array1.length
		}
		return this.n
	}
}

/* class Calculator2{
	constructor(newXArray, newYArray){
		this.xArray = newXArray
		this.yArray = newYArray
		this.count = newXArray.length || newYArray.length
		this.dividend  = 0
	}
	
	calcXYSum(){
		let XYSum = Calculator.calcSum(xArray) + Calculator.calcSum(yArray)
		return XYSum
	}
	calcDividend(){
		this.dividend = (this.count* XYSum)  - (Calculator.calcSum(xArray)) * (Calculator.calcSum(yArray))
		return this.dividend
	}
	
} */

//module.exports = Calculator