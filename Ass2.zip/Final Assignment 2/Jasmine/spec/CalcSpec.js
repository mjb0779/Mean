describe("Calculator", function() {
	var calc ;
	
	beforeEach(function(){
		calc = new Calculator([1,2,3],[1,2,3],[1,2,3]);
	});
	describe("Sum of [1,2,3] should be 6", function(){
		it("sum of [1,2,3] is 6", function(){
			expect(calc.calcSum([1,2,3])).toEqual(6)
		})
	})
	describe("MEAN of [1,2,3] should be 2", function(){
		beforeEach(function(){
			calc.sum = 6
		})
		it("MEAN of [1,2,3] is 2", function(){
			expect(calc.calcMean()).toEqual(2)
		})
	})
	describe("array2", function(){
		beforeEach(function(){
			calc.array2 = []
			calc.mean = 2
		})
		it("array2", function(){
			expect(calc.myArray2(calc.array1)).toEqual([-1,0,1])
		})
	})
	describe("sqrArray", function(){
		beforeEach(function(){
			calc.array3 = []
			calc.array2 = [-1,0,1]
		})
		it("SqrArray", function(){
			expect(calc.calcSqr(calc.array2)).toEqual([1,0,1])
		})
	})
	describe("Standard Deviation", function(){
		beforeEach(function(){
			calc.array3 = [1,0,1]
			let sum2 = calc.calcSum(calc.array3)
			
		})
		it("Should be able to get Standard Deviation of [1,2,3]", function(){
			expect(calc.calcStd(calc.calcSum([1,0,1]))).toEqual(1);
		})
	})
	describe("XYSum for correlation an regression", function(){
		it("should get sum of products", function(){
			expect(calc.calcXYSum(calc.xArray, calc.yArray)).toEqual(9)
		})
	})
	describe("sqr2", function(){
		beforeEach(function(){
			calc.inArray = []
		})
		it("Sqr2Array", function(){
			expect(calc.calcSqr2(calc.xArray, calc.inArray)).toEqual(14)
		})	
	})
	describe("number of pairs", function(){
		it("number of pairs", function(){
			expect(calc.calcN(calc.xArray, calc.yArray)).toEqual(3)
		})
	})
})

/* describe("when Calculator is used to calculate sum", function(){
		let array = [1,2,3]
		it("should be able to calculate sum of array [1,2,3]", function(){
			expect(calc.calcSum(array)).toEqual(6);
		});	
		describe("when looking for mean of [1,2,3]", function(){
			beforeEach(function(){
				calc.sum = 6;
				calc.count = array.length;
			})
			
			it("should be able to calculate mean of [1,2,3]", function(){
				expect(calc.calcMean()).toBe(2);
			})
			
			describe("when INSERTING the difference of all the numbers [1,2,3] to the MEAN in an array", function(){
				beforeEach(function(){
					calc.array1 = [1,2,3]
					calc.mean = 2
					calc.array2 = []
					
				})
				it("should get [-1,2,1] into another array by subtracting the MEAN from all the numbers in [1,2,3]", function(){
					expect(calc.myArray2()).toEqual([-1,0,1]); 
				})
				
			})
			describe("when INSERTING the Squares of all the numbers [-1,0,1] array", function(){
				beforeEach(function(){
					calc.array2 = [-1,0,1]
					calc.array3 = []					
				})
				it("should get [1,0,1] into another array by squaring each one of them", function(){
					expect(calc.calcSqr()).toEqual([1,0,1]);
				})
				
			})
			describe("When calculating Standard Deviation", function(){
				beforeEach(function(){
					calc.array3 = [1,0,1]
					let sum2 = calc.calcSum(calc.array3)
					
				})
				it("Should be able to get Standard Deviation of [1,2,3]", function(){
					expect(calc.calcStd(calc.calcSum([1,0,1]))).toEqual(1);
				})
				
			})
		})
		
	}); */