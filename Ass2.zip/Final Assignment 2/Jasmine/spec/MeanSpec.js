describe("Calculator", function() {
	var calc;
	
	beforeEach(function(){
		calc = new Calculator();
	});
	describe("when Calculator is used to calculate mean of [1,2,3]", function(){
		let array=[1,2,3]
		let sum = calc.calcSum(array)
		it("should be able to get the mean of [1,2,3]", function(){
			expect(calc.calcMean()).toEqual(2)
		})
	});
})