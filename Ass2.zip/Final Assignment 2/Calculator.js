class Calculator{
	constructor (newArray1, newXArray, newYArray) {
		this.sum = 0
		this.mean = 0
		this.count = newArray1.length
		this.sqrSum = 0
		this.std = 0
		this.array1 = newArray1
		this.xArray = newXArray
		this.yArray = newYArray
		this.array2 = []
		this.array3 = []
		this.XYSum = 0
		this.xSqr = []
		this.ySqr = []
		this.xSqrSum = 0
		this.ySqrSum = 0
		this.n = 0
		this.temp = []
	}

	calcSum(allNumber){
		this.sum = allNumber.reduce((a,b) => a+=b)
		return this.sum
	}
	
	calcMean(sum, allNumber){
		this.mean = sum/allNumber.length
		return this.mean
	}
	
	myArray2(array){
		for(let a of array){
			this.array2.push(a-this.mean)
		}
		return this.array2
		console.log(array2)
	}
	calcSqr(array){
		this.array3 = []
		for(let a of array){
			this.array3.push(a*a)
		}
		return this.array3
	}
	calcStd(sum){
		this.std = Math.sqrt(sum/(this.count-1))
		return this.std
	}
	calcXYSum(array1,array2){
		this.temp = array1.map(function (num, idx){
		return (num * array2[idx])
		})
		return this.calcSum(this.temp)
	}
	calcXYSumSqr(array1, array2){
		let tempar = []
		this.temp = array1.map(function (num, idx){
		return (num * array2[idx])
		})
		for(let a of this.temp){
			tempar.push(a*a)
		}
		return this.calcSum(tempar)
		//console.log(this.calcSum(tempar))
	}
	
	calcSqr2(array, inArray){
		for(let a of array){
			inArray.push(a*a)
		}
		return this.calcSum(inArray)
	}
}
